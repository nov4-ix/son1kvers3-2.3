/**
 * Configuration for Son1kVerse AI Music Engine Extension
 * Auto-configured for production deployment
 */

// Backend URL - Fly.io deployment
const BACKEND_URL = 'https://sub-son1k-2-2.fly.dev'

// Generator URL - Vercel deployment
const GENERATOR_URL = 'https://web-classic.vercel.app'

export default {
    BACKEND_URL,
    GENERATOR_URL
}
